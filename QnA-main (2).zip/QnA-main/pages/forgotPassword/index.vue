<template>
  <div class="mainContainer">
    <forgot-password-u-i/>
  </div>
</template>

<script>
import forgotPasswordUI from "@/components/forgotPasswordUI";
export default {
  name: "index",
  components: {
    forgotPasswordUI
  }
}
</script>

<style scoped>

</style>
